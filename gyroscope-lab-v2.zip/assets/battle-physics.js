/* 戰鬥陀螺物理核心（不依賴畫面，可單獨測試）
 * 水平面座標 (x, y)，z 向上；長度單位 m、質量 kg、時間 s
 */
(function (root) {
  'use strict';
  const g = 9.8;
  const R_TOP = 0.025;   // 陀螺半徑
  const E_MAX = 2.0;     // 轉動動能上限 (J)
  const BOWL_C = 2.0;    // 場地剖面 z = C r²
  const R_OUT = 0.24;    // 出界線
  const R_LAUNCH = 0.14; // 發射點距中心
  const C_AIR = 3e-7;    // 空氣阻力力矩係數 (N·m·s)
  const MU_ROLL = 0.04;  // 地面滾動阻力
  const MU_CONTACT = 0.35; // 碰撞時接觸面摩擦
  const TILT_FALL = 0.65;  // 傾斜超過約 37° 判定倒下
  const T_LIMIT = 60;      // 每回合最長時間
  const H_WALL = 0.04;     // 出界邊牆高度
  const V_ESC = Math.sqrt(2 * g * H_WALL); // ≈ 0.89 m/s

  /* 外型：k 決定轉動慣量 I = k m r²（質量越往外圈越大）；α 刃角；e 恢復係數 */
  const SHAPES = {
    blade:  { name: '刃鋒', type: '攻擊型', k: 0.46, alpha: 1.0,  e: 0.70, blades: 3,
              note: '質量集中在中間、刃角大：撞擊時把自轉轉換成推力，但自己也耗轉速。' },
    star:   { name: '星芒', type: '平衡型', k: 0.55, alpha: 0.6,  e: 0.62, blades: 5,
              note: '介於攻擊與持久之間，什麼都不突出也不吃虧。' },
    shield: { name: '盾環', type: '防禦型', k: 0.60, alpha: 0.2,  e: 0.45, blades: 0,
              note: '圓滑外緣、恢復係數低：撞擊能量被吸收，不容易被彈飛。' },
    wheel:  { name: '飛輪', type: '持久型', k: 0.75, alpha: 0.15, e: 0.55, blades: 8,
              note: '質量集中在外圈（像圓環），同樣能量下轉速較低，但轉得最久。' }
  };
  /* 尖端：摩擦力矩 τ = μ m g r_tip；grip 決定在場地上跑動的程度 */
  const TIPS = {
    sharp: { name: '尖頭', mu: 0.22, rtip: 0.0008, grip: 0.15, drive: 0.0,
             note: '接觸點最小 → 摩擦力矩小、最省轉速，幾乎停在中央不動。' },
    ball:  { name: '球頭', mu: 0.25, rtip: 0.0015, grip: 0.5,  drive: 0.25,
             note: '中庸：會慢慢繞場，轉速消耗中等。' },
    flat:  { name: '平頭', mu: 0.30, rtip: 0.0025, grip: 1.0,  drive: 0.7,
             note: '接觸面大 → 抓地力強、跑得快，但摩擦力矩大、轉速掉得快。' }
  };

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const hyp = Math.hypot;

  function derived(cfg) {
    const S = SHAPES[cfg.shape], T = TIPS[cfg.tip];
    const m = cfg.mass / 1000, h = cfg.h / 1000, r = R_TOP;
    const I = S.k * m * r * r;
    const Iperp = 0.5 * S.k * m * r * r + m * h * h;     // 繞尖端的橫向轉動慣量
    const wMax = Math.sqrt(2 * E_MAX / I);
    const w0 = Math.min(cfg.rpm * Math.PI / 30, wMax);
    const wc = Math.sqrt(4 * m * g * h * Iperp) / I;      // 能「睡著」直立的臨界轉速
    const tauTip = T.mu * m * g * T.rtip;
    // 不受撞擊、不跑動時的持久時間（解析解）：I ω' = −τ − c ω，轉到 ω_c 為止
    const a = tauTip / I, b = C_AIR / I;
    const tLife = Math.log((a + b * w0) / (a + b * wc)) / b;
    return { S, T, m, h, r, I, Iperp, wMax, wMaxRpm: wMax * 30 / Math.PI, w0, wc, wcRpm: wc * 30 / Math.PI,
      E: 0.5 * I * w0 * w0, L: I * w0, tauTip, tLife,
      precess: m * g * h / (I * Math.max(w0, 1)), KE: 0.5 * m * cfg.v * cfg.v };
  }

  function makeTop(cfg, side) {
    const d = derived(cfg);
    // 發射：玩家一在左 (−x)，玩家二在右 (+x)；θ=0 正對中心，+θ 為俯視順時針偏轉
    const sx = side === 0 ? -1 : 1;
    const px = sx * R_LAUNCH, py = 0;
    const toC = Math.atan2(-py, -px);
    const ang = toC - cfg.angle * Math.PI / 180;
    const dir = (cfg.spin === 'L' || cfg.spin < 0) ? -1 : 1;
    return {
      cfg, d, side, m: d.m, I: d.I, h: d.h,
      x: px, y: py, vx: Math.cos(ang) * cfg.v, vy: Math.sin(ang) * cfg.v,
      w: dir * d.w0, tx: 0, ty: 0, // tilt：軸偏離鉛直的向量（rad），方向 = 軸頂端偏移方向
      alive: true, out: false, fell: false, trail: [], wobble: 0, lastHit: null, hits: 0
    };
  }

  /* 對陀螺在接觸點施加衝量 J（水平向量），接觸點相對中心 rv */
  function applyImpulse(t, Jx, Jy, rx, ry) {
    t.vx += Jx / t.m; t.vy += Jy / t.m;
    t.w += (rx * Jy - ry * Jx) / t.I;
    // 撞擊點高度約在重心 h：角衝量 ΔL = h ẑ × J → 軸偏轉 Δa = ΔL / (I ω)
    // 注意方向是「垂直於推力」：這就是陀螺儀效應（進動）
    const Lw = t.I * (Math.abs(t.w) < 30 ? Math.sign(t.w || 1) * 30 : t.w);
    t.tx += t.h * (-Jy) / Lw;
    t.ty += t.h * (Jx) / Lw;
  }

  function collide(a, b, events) {
    const dx = b.x - a.x, dy = b.y - a.y, dist = hyp(dx, dy);
    if (dist >= 2 * R_TOP || dist < 1e-9) { a.inContact = b.inContact = false; return; }
    const fresh = !a.inContact; // 剛接觸才算一次撞擊（持續貼著互刮不重複計數）
    a.inContact = b.inContact = true;
    const nx = dx / dist, ny = dy / dist, tx = -ny, ty = nx; // n 由 a 指向 b；t = ẑ × n
    const r = R_TOP;
    // 接觸點相對速度（含自轉表面速度）：u = (va − vb) + (ωa + ωb) r t̂
    const ux = a.vx - b.vx + (a.w + b.w) * r * tx;
    const uy = a.vy - b.vy + (a.w + b.w) * r * ty;
    const un = ux * nx + uy * ny, ut = ux * tx + uy * ty;
    // 位置修正（避免重疊）
    const pen = 2 * R_TOP - dist, wa = 1 / a.m, wb = 1 / b.m;
    a.x -= nx * pen * wa / (wa + wb); a.y -= ny * pen * wa / (wa + wb);
    b.x += nx * pen * wb / (wa + wb); b.y += ny * pen * wb / (wa + wb);
    if (un <= 0) return;
    // 刃角：有效法線往滑動方向偏 α
    const al = (a.d.S.alpha + b.d.S.alpha) * Math.PI / 180, s = Math.sign(ut) || 1;
    const qx = Math.cos(al) * nx + Math.sin(al) * s * tx, qy = Math.cos(al) * ny + Math.sin(al) * s * ty;
    const uq = ux * qx + uy * qy;
    if (uq <= 0) return;
    const e = Math.min(a.d.S.e, b.d.S.e) * 0.5 + Math.max(a.d.S.e, b.d.S.e) * 0.5;
    const rax = r * nx, ray = r * ny, rbx = -r * nx, rby = -r * ny;
    const cqa = rax * qy - ray * qx, cqb = rbx * qy - rby * qx;
    const K = wa + wb + cqa * cqa / a.I + cqb * cqb / b.I;
    const J = (1 + e) * uq / K;
    applyImpulse(a, -J * qx, -J * qy, rax, ray);
    applyImpulse(b, J * qx, J * qy, rbx, rby);
    // 庫倫摩擦（垂直 q 的方向），會改變兩者自轉
    const px = -qy, py = qx;
    const ux2 = a.vx - b.vx + (a.w + b.w) * r * tx, uy2 = a.vy - b.vy + (a.w + b.w) * r * ty;
    const up = ux2 * px + uy2 * py;
    const cpa = rax * py - ray * px, cpb = rbx * py - rby * px;
    const Kt = wa + wb + cpa * cpa / a.I + cpb * cpb / b.I;
    const Jt = clamp(up / Kt, -MU_CONTACT * J, MU_CONTACT * J);
    const wa0 = a.w, wb0 = b.w;
    applyImpulse(a, -Jt * px, -Jt * py, rax, ray);
    applyImpulse(b, Jt * px, Jt * py, rbx, rby);
    if (!fresh && J < 0.004) return;
    a.hits++; b.hits++;
    const ev = { type: 'hit', J, Jt, dvA: J / a.m, dvB: J / b.m,
      dwA: a.w - wa0, dwB: b.w - wb0, sameSpin: Math.sign(a.w) === Math.sign(b.w), slide: Math.abs(ut) };
    a.lastHit = ev; b.lastHit = ev;
    events.push(ev);
  }

  function stepTop(t, dt, events) {
    if (!t.alive) return;
    const d = t.d, T = d.T;
    const aw = Math.abs(t.w), sg = Math.sign(t.w) || 1;
    // 1) 自轉衰減：I ω' = −(μ m g r_tip) − c ω
    let dw = (d.tauTip + C_AIR * aw) / t.I * dt;
    // 2) 平移：碗形場地回復力 + 滾動阻力 + 尖端帶動
    const r = hyp(t.x, t.y), sp = hyp(t.vx, t.vy);
    let ax = -2 * g * BOWL_C * t.x, ay = -2 * g * BOWL_C * t.y;
    if (sp > 1e-4) { ax -= MU_ROLL * g * t.vx / sp; ay -= MU_ROLL * g * t.vy / sp; }
    const spinF = Math.tanh(aw / 150);
    // 自轉與地面接觸產生側向力 → 路徑彎曲
    const curve = 0.8 * T.grip * spinF * sg;
    ax += -t.vy * curve; ay += t.vx * curve;
    // 平頭／球頭：尖端「滾動」推著陀螺沿場地繞圈（能量來自自轉）
    if (T.drive > 0 && r > 0.01) {
      const ex = -t.y / r * sg, ey = t.x / r * sg;
      const dr = T.drive * spinF;
      ax += ex * dr; ay += ey * dr;
      const P = t.m * dr * Math.max(0, ex * t.vx + ey * t.vy); // 推進功率
      dw += P / (t.I * Math.max(aw, 20)) * dt;
    }
    t.vx += ax * dt; t.vy += ay * dt;
    t.x += t.vx * dt; t.y += t.vy * dt;
    t.w = aw - dw <= 0 ? 0 : sg * (aw - dw);
    // 3) 傾斜：重力力矩 m g h 讓軸以 Ω = m g h /(I ω) 進動；轉速夠快會慢慢回正
    const tilt = hyp(t.tx, t.ty);
    if (aw > 1) {
      const Om = d.m * g * d.h / (t.I * aw) * sg;
      const c = Math.cos(Om * dt), s = Math.sin(Om * dt);
      const nx = t.tx * c - t.ty * s, ny = t.tx * s + t.ty * c; t.tx = nx; t.ty = ny;
    }
    if (aw > d.wc) {
      const k = Math.exp(-dt / 1.2);
      t.tx *= k; t.ty *= k;
    } else {
      const grow = 1 + (0.8 + 4 * (1 - aw / d.wc)) * dt;
      if (tilt < 0.02) { t.tx += 0.02 * dt; }
      t.tx *= grow; t.ty *= grow;
    }
    t.wobble = hyp(t.tx, t.ty);
    // 4) 判定
    const r2 = hyp(t.x, t.y);
    if (r2 > R_OUT) {
      // 邊牆高 H_WALL：徑向速度要大於 √(2 g H) 才翻得出去，否則撞牆反彈
      const ux = t.x / r2, uy = t.y / r2, vr = t.vx * ux + t.vy * uy;
      if (vr > V_ESC) { t.alive = false; t.out = true; events.push({ type: 'out', side: t.side, vr }); }
      else {
        t.x = ux * R_OUT; t.y = uy * R_OUT;
        if (vr > 0) {
          const J = (1 + 0.3) * t.m * vr;
          applyImpulse(t, -J * ux, -J * uy, ux * R_TOP, uy * R_TOP);
          t.w *= 0.985;
          events.push({ type: 'wall', side: t.side, vr });
        }
      }
    }
    if (!t.alive) { /* 已出界 */ }
    else if (t.wobble > TILT_FALL || aw < d.wc * 0.5) { t.alive = false; t.fell = true; events.push({ type: 'fall', side: t.side, byHit: t.wobble > TILT_FALL && aw > d.wc }); }
  }

  class Battle {
    constructor(cfgA, cfgB) {
      this.tops = [makeTop(cfgA, 0), makeTop(cfgB, 1)];
      this.t = 0; this.over = false; this.result = null; this.events = []; this.log = [];
    }
    step(dt) {
      if (this.over) return [];
      const ev = [];
      const [a, b] = this.tops;
      stepTop(a, dt, ev); stepTop(b, dt, ev);
      if (a.alive && b.alive) collide(a, b, ev);
      this.t += dt;
      const aliveA = a.alive, aliveB = b.alive;
      if (!aliveA || !aliveB || this.t >= T_LIMIT) {
        this.over = true;
        let winner, method;
        if (!aliveA && !aliveB) { winner = -1; method = '同時倒下'; }
        else if (!aliveA || !aliveB) {
          const loser = aliveA ? b : a; winner = aliveA ? 0 : 1;
          method = loser.out ? '出界' : (ev.find(e => e.type === 'fall' && e.byHit) ? '被撞倒' : '轉速耗盡');
        } else {
          const La = Math.abs(a.I * a.w), Lb = Math.abs(b.I * b.w);
          winner = La === Lb ? -1 : (La > Lb ? 0 : 1); method = '時間到（比角動量）';
        }
        this.result = { winner, method, time: this.t };
      }
      for (const e of ev) this.log.push(Object.assign({ t: this.t }, e));
      return ev;
    }
  }

  const api = { SHAPES, TIPS, derived, Battle, R_TOP, E_MAX, BOWL_C, R_OUT, R_LAUNCH, T_LIMIT, H_WALL, V_ESC, TILT_FALL, C_AIR, MU_ROLL, MU_CONTACT, g };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BattlePhysics = api;
})(this);
