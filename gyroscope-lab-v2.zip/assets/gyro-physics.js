/* 陀螺儀物理核心（不依賴畫面，可單獨測試）
 * 座標（物理）：x 向前、y 向左、z 向上（右手座標）
 * 1) HeavyTop：一端支點的陀螺儀（重對稱陀螺），可算進動、章動、倒下
 * 2) BoatGyro：船＋鉸鏈轉盤（船體橫搖 φ 與轉盤前後俯仰 θ 的耦合）
 */
(function (root) {
  'use strict';
  const g = 9.8;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  /* ---------- 1. 重對稱陀螺（支點在軸的一端） ----------
   * θ：軸與鉛直向上的夾角（90° = 水平）；φ：進動角（俯視逆時針為正）
   * ψ：自轉角；ω3：飛輪自轉角速度（沿軸，從支點指向飛輪為正）
   * pφ = I1 φ' sin²θ + I3 ω3 cosθ （鉛直方向角動量，只被鉛直力矩改變）
   * I1 θ'' = I1 φ'² sinθ cosθ − I3 ω3 φ' sinθ + τg sinθ
   * τg = g(m_d l_d − m_c d_c) + 使用者往下推的力 × 力臂 */
  class HeavyTop {
    constructor(p) {
      this.p = Object.assign({
        md: 0.2, R: 0.04, ld: 0.08,   // 飛輪質量、半徑、到支點距離
        mc: 0.15, dc: 0.0,            // 配重質量、配重到支點距離（另一側）
        rpm: 4000, motor: true,       // 轉速、馬達是否持續供電
        damp: 0.0006, dampYaw: 0.00015, bearing: 0.06 // 支點阻尼、軸承衰減率 (1/s)
      }, p || {});
      this.forceDown = 0;  // 使用者施力（N，在飛輪處，往下為正）
      this.forceSide = 0;  // 使用者水平推力（N，沿進動正方向）
      this.reset();
    }
    get I3() { return 0.5 * this.p.md * this.p.R * this.p.R; }
    get I1() { const p = this.p; return p.md * (p.R * p.R / 4 + p.ld * p.ld) + p.mc * p.dc * p.dc + 0.00015; }
    get tauG() { const p = this.p; return g * (p.md * p.ld - p.mc * p.dc); }
    get tau() { return this.tauG + this.forceDown * this.p.ld; }
    get L() { return this.I3 * this.w3; }
    /* 快速陀螺的理論進動角速度 Ω = τ / (I3 ω3) */
    get omegaTheory() { return Math.abs(this.w3) < 1e-6 ? NaN : this.tau / (this.I3 * this.w3); }
    get phiDot() {
      const s = Math.sin(this.th);
      return (this.pphi - this.I3 * this.w3 * Math.cos(this.th)) / (this.I1 * s * s);
    }
    reset(opts) {
      opts = opts || {};
      this.t = 0;
      this.th = Math.PI / 2; this.thd = 0;
      this.phi = opts.phi || 0; this.psi = 0;
      this.w3 = this.p.rpm * Math.PI / 30;
      this.fallen = false;
      // smooth=true：一開始就給剛好的進動速度 → 沒有章動
      const phid0 = opts.smooth && Math.abs(this.w3) > 1 ? this.tau / (this.I3 * this.w3) : 0;
      this.pphi = this.I1 * phid0 + this.I3 * this.w3 * Math.cos(this.th);
    }
    setRpm(rpm) { this.p.rpm = rpm; if (this.p.motor) this.w3 = rpm * Math.PI / 30; }
    deriv(s) {
      const [th, thd, , pphi] = s;
      const p = this.p, I1 = this.I1, I3w = this.I3 * this.w3;
      const sn = Math.max(Math.sin(th), 0.05), cs = Math.cos(th);
      const phid = (pphi - I3w * cs) / (I1 * sn * sn);
      let thdd = (I1 * phid * phid * sn * cs - I3w * phid * sn + this.tau * sn - p.damp * thd) / I1;
      // 擋塊：軸最多往下垂到 θ=140°、往上到 40°
      const lo = 40 * Math.PI / 180, hi = 140 * Math.PI / 180;
      if (th > hi) thdd += (-(th - hi) * 400 - thd * 25);
      if (th < lo) thdd += (-(th - lo) * 400 - thd * 25);
      const dpphi = this.forceSide * p.ld * sn - p.dampYaw * phid;
      return [thd, thdd, phid, dpphi, this.w3 - phid * cs];
    }
    step(dt) {
      if (!this.p.motor) { // 馬達關掉：軸承摩擦讓轉速慢慢下降
        const w0 = this.w3;
        this.w3 = w0 * Math.exp(-this.p.bearing * dt) - Math.sign(w0) * 2 * dt;
        if (w0 * this.w3 <= 0) this.w3 = 0;
        // 自轉變慢時 pφ 不變（鉛直方向沒有外力矩），由 deriv 自動處理
      }
      const s = [this.th, this.thd, this.phi, this.pphi, this.psi];
      const k1 = this.deriv(s);
      const a = (k, h) => s.map((v, i) => v + k[i] * h);
      const k2 = this.deriv(a(k1, dt / 2));
      const k3 = this.deriv(a(k2, dt / 2));
      const k4 = this.deriv(a(k3, dt));
      const n = s.map((v, i) => v + dt / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]));
      [this.th, this.thd, this.phi, this.pphi, this.psi] = n;
      this.t += dt;
      this.fallen = this.th > 135 * Math.PI / 180 || this.th < 45 * Math.PI / 180;
    }
    /* 軸方向單位向量（物理座標） */
    axis() {
      const s = Math.sin(this.th);
      return [s * Math.cos(this.phi), s * Math.sin(this.phi), Math.cos(this.th)];
    }
    /* 重力（含施力）力矩向量 τ = r × F，水平且垂直於軸 */
    torqueVec() {
      const n = this.axis(); // ẑ × n = (−n_y, n_x, 0)
      return [-n[1] * this.tau, n[0] * this.tau, 0];
    }
  }

  /* ---------- 2. 船＋鉸鏈轉盤 ----------
   * φ：船橫搖（繞 x 軸，正 = 往右舷傾）；θ：轉盤繞橫向鉸鏈俯仰（正 = 轉盤頂端往船頭倒）
   * L：轉盤角動量（正 = 俯視逆時針、L 朝上）
   * 推導：dL/dt = (φ' x̂ + θ' ŷ) × Lẑ = L(θ' x̂ − φ' ŷ)
   *   鉸鏈方向（ŷ）沒有力矩可傳 → I_g θ'' = L φ' − k_g sinθ − c_g θ'
   *   船受到反作用力矩 → I_b φ'' = −k_b φ − c_b φ' − L θ' cosθ + τ外
   * 兩個耦合項一正一負，總能量守恆（陀螺力不做功） */
  class BoatGyro {
    constructor(p) {
      this.p = Object.assign({
        Ib: 1.0, kb: 4.0, cb: 0.12,   // 船：橫搖慣量、浮力回正、水阻
        Ig: 0.06, kg: 0.35, cg: 0.25, // 轉盤架：俯仰慣量、重心偏低的回正、鉸鏈阻尼
        L: 1.0,                       // 轉盤角動量（正 = 逆時針）
        maxTip: 1.0                   // 鉸鏈擋塊（rad）
      }, p || {});
      this.reset();
    }
    reset() { this.t = 0; this.phi = 0; this.phid = 0; this.th = 0; this.thd = 0; this.tauExt = 0; }
    deriv(s) {
      const [phi, phid, th, thd] = s, p = this.p;
      const c = Math.cos(th);
      let thdd = (p.L * phid * c - p.kg * Math.sin(th) - p.cg * thd) / p.Ig;
      const m = p.maxTip;
      if (th > m) thdd += (-(th - m) * 300 - thd * 20);
      if (th < -m) thdd += (-(th + m) * 300 - thd * 20);
      const phidd = (-p.kb * phi - p.cb * phid - p.L * thd * c + this.tauExt) / p.Ib;
      return [phid, phidd, thd, thdd];
    }
    step(dt) {
      const s = [this.phi, this.phid, this.th, this.thd];
      const k1 = this.deriv(s);
      const a = (k, h) => s.map((v, i) => v + k[i] * h);
      const k2 = this.deriv(a(k1, dt / 2));
      const k3 = this.deriv(a(k2, dt / 2));
      const k4 = this.deriv(a(k3, dt));
      [this.phi, this.phid, this.th, this.thd] = s.map((v, i) => v + dt / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]));
      this.t += dt;
    }
    energy() {
      const p = this.p;
      return 0.5 * p.Ib * this.phid ** 2 + 0.5 * p.kb * this.phi ** 2 + 0.5 * p.Ig * this.thd ** 2 + p.kg * (1 - Math.cos(this.th));
    }
  }

  const api = { HeavyTop, BoatGyro, g, clamp };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.GyroPhysics = api;
})(this);
