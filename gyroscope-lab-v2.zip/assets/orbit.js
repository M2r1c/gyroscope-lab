/* 簡易環繞相機：拖曳旋轉、滾輪／雙指縮放（不需額外函式庫） */
(function (root) {
  'use strict';
  class Orbit {
    constructor(camera, dom, opts) {
      opts = opts || {};
      this.camera = camera; this.dom = dom;
      this.target = opts.target || new THREE.Vector3(0, 0, 0);
      this.dist = opts.dist || 5; this.yaw = opts.yaw || 0.6; this.pitch = opts.pitch || 0.5;
      this.minDist = opts.minDist || 1; this.maxDist = opts.maxDist || 30;
      this.minPitch = opts.minPitch != null ? opts.minPitch : 0.05; this.maxPitch = opts.maxPitch || 1.5;
      this.home = { dist: this.dist, yaw: this.yaw, pitch: this.pitch };
      this.pointers = new Map();
      dom.style.touchAction = 'none';
      dom.addEventListener('pointerdown', e => { if (this.enabled === false) return; dom.setPointerCapture(e.pointerId); this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY }); });
      dom.addEventListener('pointermove', e => {
        if (this.enabled === false || !this.pointers.has(e.pointerId)) return;
        const p = this.pointers.get(e.pointerId);
        if (this.pointers.size === 1) {
          this.yaw -= (e.clientX - p.x) * 0.008;
          this.pitch = Math.max(this.minPitch, Math.min(this.maxPitch, this.pitch + (e.clientY - p.y) * 0.006));
        } else if (this.pointers.size === 2) {
          const pts = [...this.pointers.values()];
          const d0 = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
          p.x = e.clientX; p.y = e.clientY;
          const pts2 = [...this.pointers.values()];
          const d1 = Math.hypot(pts2[0].x - pts2[1].x, pts2[0].y - pts2[1].y);
          if (d0 > 0) this.zoom(d0 / d1);
        }
        p.x = e.clientX; p.y = e.clientY;
        this.update();
      });
      const up = e => this.pointers.delete(e.pointerId);
      dom.addEventListener('pointerup', up); dom.addEventListener('pointercancel', up);
      dom.addEventListener('wheel', e => { if (this.enabled === false) return; e.preventDefault(); this.zoom(Math.exp(e.deltaY * 0.001)); this.update(); }, { passive: false });
      this.update();
    }
    zoom(f) { this.dist = Math.max(this.minDist, Math.min(this.maxDist, this.dist * f)); }
    reset() { Object.assign(this, this.home); this.update(); }
    update() {
      const c = Math.cos(this.pitch), t = this.target;
      this.camera.position.set(t.x + this.dist * c * Math.sin(this.yaw), t.y + this.dist * Math.sin(this.pitch), t.z + this.dist * c * Math.cos(this.yaw));
      this.camera.lookAt(t);
    }
  }
  /* 讓 3D 物件旁邊顯示 HTML 標籤 */
  function placeLabel(el, pos3, camera, w, h) {
    const v = pos3.clone().project(camera);
    if (v.z > 1) { el.style.display = 'none'; return; }
    el.style.display = '';
    el.style.left = ((v.x + 1) / 2 * w) + 'px';
    el.style.top = ((1 - v.y) / 2 * h) + 'px';
  }
  /* 滑桿進度條顏色 */
  function paintRange(input) {
    const pct = (input.value - input.min) / (input.max - input.min) * 100;
    input.style.setProperty('--pct', pct + '%');
  }
  root.Orbit = Orbit; root.placeLabel = placeLabel; root.paintRange = paintRange;
})(this);
